- Do not include this directory into your codebase (i.e., git repo) for P2, this
  is a separate demo.
- Compile with the Makefile and run to see the produced output.
- Now look at the code and try to understand it.
    - You'll want to follow the execution step by step, and understand how we
      switch from one thread to another.
    - The more you understand about this code, the easier it will be to
      implement Phase 2 of the project.
    - You'll also want to understand why `ctx[0]` is not initialized like the
      other objects of the array.
